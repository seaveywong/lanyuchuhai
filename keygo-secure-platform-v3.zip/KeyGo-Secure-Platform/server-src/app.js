require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const crypto = require('crypto');
const config = require('./config');
const logger = require('./utils/logger');
const { errorHandler } = require('./middleware/errorHandler');
const { apiLimiter } = require('./middleware/rateLimiter');
const { adminIpGuard } = require('./middleware/adminIpGuard');
const { requestGuard } = require('./middleware/requestGuard');

const app = express();

app.disable('x-powered-by');
app.set('trust proxy', config.app.trustProxy);

app.use((req, res, next) => {
  req.id = req.headers['x-request-id'] || crypto.randomUUID();
  res.setHeader('X-Request-Id', req.id);
  next();
});

app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
}));

app.use(cors({
  origin(origin, callback) {
    if (!origin) return callback(null, true);
    if (config.app.allowedOrigins.includes(origin)) return callback(null, true);
    if (!config.isProduction && config.app.allowedOrigins.length === 0) return callback(null, true);
    return callback(new Error('CORS origin denied'));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-Id'],
  maxAge: 86400,
}));

app.use(morgan(config.isProduction ? 'combined' : 'dev'));

const defaultJsonParser = express.json({ limit: config.bodyLimit });
const defaultUrlencodedParser = express.urlencoded({ extended: false, limit: config.bodyLimit });
const callbackJsonParser = express.json({ limit: config.callbackBodyLimit });
const callbackUrlencodedParser = express.urlencoded({ extended: false, limit: config.callbackBodyLimit });

app.use((req, res, next) => {
  if (req.path.startsWith('/api/callback')) return next();
  return defaultJsonParser(req, res, next);
});
app.use((req, res, next) => {
  if (req.path.startsWith('/api/callback')) return next();
  return defaultUrlencodedParser(req, res, next);
});
app.use((req, res, next) => {
  if (req.path.startsWith('/api/callback')) return next();
  return requestGuard(req, res, next);
});
app.use(require('./middleware/securityHeaders'));

app.use('/api/admin', require('./middleware/bruteForce').blockCheck, adminIpGuard);
app.use('/api/', apiLimiter);

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', app: config.app.name, requestId: req.id, timestamp: new Date().toISOString() });
});

app.use('/api/public', require('./controllers/public/product'));
app.use('/api/public', require('./controllers/public/order'));
app.use('/api/public', require('./controllers/public/payment'));

app.use('/api/admin', require('./controllers/admin/auth'));
app.use('/api/admin', require('./controllers/admin/product'));
app.use('/api/admin', require('./controllers/admin/inventory'));
app.use('/api/admin', require('./controllers/admin/order'));
app.use('/api/admin', require('./controllers/admin/paymentConfig'));
app.use('/api/admin', require('./controllers/admin/dashboard'));

app.use('/api/callback', callbackJsonParser, callbackUrlencodedParser, requestGuard, require('./controllers/public/callback'));

app.use((req, res) => {
  res.status(404).json({ error: '接口不存在', requestId: req.id });
});

app.use(errorHandler);

if (require.main === module) {
  try {
    require('./jobs/usdtMonitor');
    logger.info('USDT monitor job started');
  } catch (err) {
    logger.warn('USDT monitor job skipped (missing config)', { error: err.message });
  }

  try {
    require('./jobs/cleanup');
    logger.info('Cleanup job started');
  } catch (err) {
    logger.warn('Cleanup job skipped', { error: err.message });
  }

  app.listen(config.port, () => {
    logger.info(`Server running on port ${config.port}`);
    logger.info(`Environment: ${config.nodeEnv}`);
    logger.info(`API: http://localhost:${config.port}/api/health`);
  });
}

module.exports = app;
