/**
 * 公开接口 — 支付方式 + 汇率
 */
const { Router } = require('express');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();
const router = Router();

// GET /api/public/payment/config — 获取启用的支付方式 + 汇率
router.get('/payment/config', async (req, res, next) => {
  try {
    const configs = await prisma.paymentConfig.findMany({
      where: { status: 'active' },
    });

    // 从 usdt_trc20 配置中提取汇率（默认 7.0）
    let exchangeRate = 7.0;
    const usdtConfig = configs.find(c => c.method === 'usdt_trc20');
    if (usdtConfig && usdtConfig.configJson) {
      try {
        const cfg = JSON.parse(usdtConfig.configJson);
        if (cfg.exchangeRate) exchangeRate = parseFloat(cfg.exchangeRate);
      } catch (e) { /* ignore */ }
    }

    // 客服联系方式（从 site_settings 配置中读取）
    let contact = null;
    const siteCfg = configs.find(c => c.method === 'site_settings');
    if (siteCfg && siteCfg.configJson) {
      try {
        const cfg = JSON.parse(siteCfg.configJson);
        contact = { tgUsername: cfg.tgUsername || null, tgUrl: cfg.tgUrl || null };
      } catch (e) { /* ignore */ }
    }

    res.json({
      methods: configs.filter(c => c.method !== 'site_settings').map((c) => ({
        method: c.method,
        label: methodLabels[c.method] || c.method,
      })),
      exchangeRate,
      contact,
    });
  } catch (err) {
    next(err);
  }
});

const methodLabels = {
  usdt_trc20: 'USDT-TRC20',
  alipay: '支付宝',
  wechat: '微信支付',
};

module.exports = router;
