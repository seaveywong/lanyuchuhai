const config = require('../config');

function normalizeIp(ip = '') {
  return ip.replace('::ffff:', '').trim();
}

function adminIpGuard(req, res, next) {
  const whitelist = config.app.adminAllowedIps || [];
  if (!config.isProduction || whitelist.length === 0) return next();

  const forwarded = req.headers['x-forwarded-for'];
  const rawIp = Array.isArray(forwarded)
    ? forwarded[0]
    : (forwarded || req.ip || req.socket.remoteAddress || '').split(',')[0];
  const ip = normalizeIp(rawIp);

  if (!whitelist.includes(ip)) {
    return res.status(403).json({
      error: '当前 IP 不在管理后台白名单中',
      code: 'ADMIN_IP_DENIED',
    });
  }

  next();
}

module.exports = { adminIpGuard };
