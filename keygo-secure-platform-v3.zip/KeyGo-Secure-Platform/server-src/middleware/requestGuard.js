/**
 * 拦截明显异常的请求体 key，降低对象注入/原型污染风险。
 */
const BLOCKED_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

function hasUnsafeKey(value) {
  if (!value || typeof value !== 'object') return false;
  if (Array.isArray(value)) return value.some(hasUnsafeKey);

  return Object.keys(value).some((key) => {
    if (BLOCKED_KEYS.has(key)) return true;
    if (key.startsWith('$')) return true;
    return hasUnsafeKey(value[key]);
  });
}

function requestGuard(req, res, next) {
  if (hasUnsafeKey(req.body) || hasUnsafeKey(req.query) || hasUnsafeKey(req.params)) {
    return res.status(400).json({
      error: '请求参数包含非法字段',
      code: 'UNSAFE_REQUEST',
    });
  }
  next();
}

module.exports = { requestGuard };
