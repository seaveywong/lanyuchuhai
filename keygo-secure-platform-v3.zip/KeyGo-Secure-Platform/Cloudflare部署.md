# Cloudflare 部署指南

## 架构

```
用户 → Cloudflare DNS + CDN
         │
         ├── shop.your-domain.com → Pages (React SPA 静态托管)
         ├── api.your-domain.com  → Workers 或 VPS (Node.js API)
         └── WAF (Web Application Firewall)
```

## 方案 A: Cloudflare Pages + VPS（推荐，免费额度够用）

前端用 Pages（免费无限流量），后端用便宜 VPS。

### 1. Cloudflare Pages 部署前端

```bash
# 本地构建
cd client && npm run build

# 方式1: 连接 GitHub，自动构建部署
# Cloudflare Dashboard → Pages → Create Project → Connect Git

# 方式2: 手动部署
npx wrangler pages deploy dist --project-name=keygo
```

Pages 配置：
- Build command: `cd client && npm ci && npm run build`
- Build output: `client/dist`
- 环境变量（可选，前端不需要）

### 2. VPS 部署后端

VPS 只需跑后端 API，不需要托管前端。

```bash
# VPS 上
apt install nginx mysql-server certbot nodejs npm -y

# 部署后端
cd /var/www
git clone <repo> keygo-api
cd keygo-api/server
cp .env.example .env
# 编辑 .env：数据库密码、密钥、USDT地址等
npm ci --omit=dev
npx prisma generate
npx prisma db push
node prisma/seed.js

# PM2 启动
npm i -g pm2
pm2 start src/app.js --name keygo-api -i 2
pm2 save && pm2 startup

# Nginx 配置
cat > /etc/nginx/sites-available/keygo-api << 'EOF'
server {
    listen 443 ssl;
    server_name api.your-domain.com;

    ssl_certificate     /etc/letsencrypt/live/api.your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.your-domain.com/privkey.pem;

    # Cloudflare IP 范围才允许访问（可选）
    # include /etc/nginx/cloudflare.conf;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto https;

        # 限流 — Nginx 层
        limit_req zone=api burst=20 nodelay;
        limit_req_status 429;
    }
}

# 限流区域
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
EOF

certbot --nginx -d api.your-domain.com
```

### 3. Cloudflare WAF 规则（免费）

在 Cloudflare Dashboard → Security → WAF 添加：

```
# 规则1: 限制 /api/admin/login 频率
(uri.path eq "/api/admin/login" and http.request.method eq "POST")
→ Block, 5 requests per 1 minute

# 规则2: 拦截可疑 User-Agent
(http.user_agent contains "sqlmap" or http.user_agent contains "nikto")
→ Block

# 规则3: 拦截恶意路径扫描
(uri.path contains "/wp-admin" or uri.path contains "/.env" or uri.path contains "/.git")
→ Block

# 规则4: 仅允许你的域名访问
(not http.host in {"shop.your-domain.com" "api.your-domain.com"})
→ Block
```

### 4. Cloudflare 缓存规则

```
# 静态资源缓存
(uri.path matches "\\.(js|css|png|jpg|jpeg|gif|ico|svg|woff2)$")
→ Cache Level: Standard, Edge TTL: 30 days

# API 不缓存
(uri.path contains "/api/")
→ Cache Level: Bypass
```

### 5. DNS 设置

```
Type    Name    Content
A       @       <VPS IP>        (or Cloudflare Tunnel)
CNAME   api     @
CNAME   shop    keygo.pages.dev
```

### 6. 环境变量（VPS 后端 .env）

```bash
NODE_ENV=production
PORT=3000
DATABASE_URL="mysql://user:StrongPass@127.0.0.1:3306/fb_card"

# 生成: openssl rand -hex 32
JWT_ACCESS_SECRET=<64 hex>
JWT_REFRESH_SECRET=<64 hex>
CARD_ENCRYPTION_KEY=<64 hex>

# USDT
TRONGRID_API_KEY=xxx
MERCHANT_WALLET_ADDRESS=TRx...
MERCHANT_PRIVATE_KEY=xxx

BASE_URL=https://api.your-domain.com
```

## 方案 B: 纯 Cloudflare（Workers，Beta 有限制）

前端 Pages + 后端 Workers + D1 数据库（SQLite兼容）。

优点：完全免费、全球边缘节点
缺点：Workers 有 10ms CPU 限制，不适合加密/解密操作；D1 有存储限制

**不推荐**用于此项目——卡密加密是 CPU 密集操作，Workers 不适合。

## 上线检查清单

- [ ] 域名 DNS 指向 Cloudflare
- [ ] SSL 设为 Full (strict)
- [ ] WAF 规则已启用
- [ ] .env 所有默认密码已修改
- [ ] 数据库仅监听 127.0.0.1
- [ ] VPS 防火墙仅开放 443
- [ ] PM2 开机自启
- [ ] 完整下单→支付→查单流程测试通过
