(function () {
  'use strict';

  const BRAND = {
    cn: '钥达',
    en: 'KeyGo',
    full: '钥达 KeyGo',
    tagline: 'Secure Digital Delivery',
    subtitle: '安全数字交付平台',
  };

  const replacements = new Map([
    ['速钥 · 管理后台', 'KeyGo Admin'],
    ['速钥', BRAND.full],
    ['自助发卡平台', BRAND.subtitle],
    ['支付即交付', BRAND.tagline],
    ['全自动数字商品发卡平台', BRAND.subtitle],
    ['开始选购', '浏览商品'],
    ['为什么选择速钥', '为什么选择 钥达 KeyGo'],
    ['为什么选择 KeyGo', '为什么选择 钥达 KeyGo'],
    ['Facebook 账号、广告账户、BM、Google Ads、Cookie、Token 等全品类支持', '账号、软件授权、订阅密钥、服务凭证等多类型数字商品，适配独立站和海外业务'],
    ['卡密 AES-256 军事级加密存储，仅支付成功时解密，生产环境前后端域名隔离', '敏感数据加密存储、分域隔离与访问控制，兼顾交付效率和企业级安全治理'],
  ]);

  function replaceText(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const node of nodes) {
      let value = node.nodeValue;
      for (const [from, to] of replacements.entries()) {
        value = value.split(from).join(to);
      }
      if (value !== node.nodeValue) node.nodeValue = value;
    }
  }

  function injectBrandSystem() {
    document.title = '钥达 KeyGo | Secure Digital Delivery';

    if (!document.querySelector('.keygo-security-bar')) {
      const bar = document.createElement('div');
      bar.className = 'keygo-security-bar';
      bar.innerHTML = [
        '<span><strong>钥达 KeyGo</strong> Digital Delivery Platform</span>',
        '<span>AES-256 encrypted inventory</span>',
        '<span>Automated payment validation</span>',
        '<span>Global-ready checkout</span>',
      ].join('');
      document.body.prepend(bar);
    }

    if (!document.querySelector('.keygo-brand-watermark')) {
      const wm = document.createElement('div');
      wm.className = 'keygo-brand-watermark';
      wm.innerHTML = '<img src="/favicon.svg" alt=""> <span>钥达 KeyGo</span>';
      document.body.appendChild(wm);
    }
  }

  function run() {
    injectBrandSystem();
    replaceText(document.body);
  }

  const observer = new MutationObserver(() => {
    window.requestAnimationFrame(run);
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      run();
      observer.observe(document.body, { childList: true, subtree: true });
    });
  } else {
    run();
    observer.observe(document.body, { childList: true, subtree: true });
  }
})();
